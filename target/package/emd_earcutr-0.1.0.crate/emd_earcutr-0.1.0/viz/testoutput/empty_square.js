testOutput["empty_square"]=[];
testOutput["empty_square"]["json"]=[[[0.0, 0.0], [4000.0, 0.0], [4000.0, 4000.0], [0.0, 4000.0]], [[0.0, 0.0], [4000.0, 0.0], [4000.0, 4000.0], [0.0, 4000.0]]];
testOutput["empty_square"]["triangles"]=[];
testOutput["empty_square"]["pass"]=true;
testOutput["empty_square"]["report"]="exp numtri:0\nexp dev:0.00000000000001\nact numtri:0\nact dev:0";
