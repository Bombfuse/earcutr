testOutput["bad_diagonals"]=[];
testOutput["bad_diagonals"]["json"]=[[[440.0, 4152.0], [440.0, 4208.0], [296.0, 4192.0], [368.0, 4192.0], [400.0, 4200.0], [400.0, 4176.0], [368.0, 4192.0], [296.0, 4192.0], [264.0, 4200.0], [288.0, 4160.0], [296.0, 4192.0]]];
testOutput["bad_diagonals"]["triangles"]=[8, 9, 7, 7, 5, 6, 5, 10, 0, 2, 3, 4, 4, 5, 0, 1, 2, 4, 4, 0, 1];
testOutput["bad_diagonals"]["pass"]=true;
testOutput["bad_diagonals"]["report"]="exp numtri:7\nexp dev:0.00000000000001\nact numtri:7\nact dev:0";
