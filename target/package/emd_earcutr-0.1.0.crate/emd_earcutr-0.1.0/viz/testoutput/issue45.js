testOutput["issue45"]=[];
testOutput["issue45"]["json"]=[[[10.0, 10.0], [25.0, 10.0], [25.0, 40.0], [10.0, 40.0]], [[15.0, 30.0], [20.0, 35.0], [10.0, 40.0]], [[15.0, 15.0], [15.0, 20.0], [20.0, 15.0]]];
testOutput["issue45"]["triangles"]=[2, 6, 5, 4, 3, 0, 0, 7, 8, 9, 7, 0, 1, 2, 5, 5, 4, 0, 9, 0, 1, 5, 0, 8, 9, 1, 5, 5, 8, 9];
testOutput["issue45"]["pass"]=true;
testOutput["issue45"]["report"]="exp numtri:10\nexp dev:0.00000000000001\nact numtri:10\nact dev:0";
