testOutput["shared_points"]=[];
testOutput["shared_points"]["json"]=[[[4136.0, 1016.0], [4112.0, 1016.0], [4104.0, 976.0], [4136.0, 1016.0], [4144.0, 984.0], [4104.0, 976.0], [4144.0, 968.0], [4144.0, 984.0], [4168.0, 992.0], [4152.0, 1064.0]]];
testOutput["shared_points"]["triangles"]=[8, 9, 7, 7, 5, 6, 0, 1, 2, 9, 3, 4];
testOutput["shared_points"]["pass"]=true;
testOutput["shared_points"]["report"]="exp numtri:4\nexp dev:0.00000000000001\nact numtri:4\nact dev:0";
