testOutput["degenerate"]=[];
testOutput["degenerate"]["json"]=[[[100.0, 100.0], [100.0, 100.0], [200.0, 100.0], [200.0, 200.0], [200.0, 100.0], [0.0, 100.0]]];
testOutput["degenerate"]["triangles"]=[];
testOutput["degenerate"]["pass"]=true;
testOutput["degenerate"]["report"]="exp numtri:0\nexp dev:0.00000000000001\nact numtri:0\nact dev:0";
