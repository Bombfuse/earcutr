testOutput["steiner"]=[];
testOutput["steiner"]["json"]=[[[0.0, 0.0], [100.0, 0.0], [100.0, 100.0], [0.0, 100.0]], [[50.0, 50.0]], [[30.0, 40.0]], [[70.0, 60.0]], [[20.0, 70.0]]];
testOutput["steiner"]["triangles"]=[3, 0, 7, 7, 0, 5, 5, 0, 1, 2, 3, 7, 7, 5, 4, 6, 5, 1, 2, 7, 4, 6, 1, 2, 2, 4, 6];
testOutput["steiner"]["pass"]=true;
testOutput["steiner"]["report"]="exp numtri:9\nexp dev:0.00000000000001\nact numtri:9\nact dev:0";
