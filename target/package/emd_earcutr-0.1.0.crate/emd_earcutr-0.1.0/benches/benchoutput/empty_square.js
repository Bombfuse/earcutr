testOutput["empty_square"]["benchmark"]=[0,0,[]];
